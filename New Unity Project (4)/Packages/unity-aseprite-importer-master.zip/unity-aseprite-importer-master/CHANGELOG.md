# 1.0.1
- Minor changes for compatibility with the Unity Package Manager

# 1.0.0
- Release of the unity-aseprite-importer.